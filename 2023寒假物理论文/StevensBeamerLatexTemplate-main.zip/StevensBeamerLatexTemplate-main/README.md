# The unofficial Stevens Beamer Latex  Presentation Template
Has all the Stevens colors, logos etc. 
See the pdf and the .tex file to learn how to use it 
